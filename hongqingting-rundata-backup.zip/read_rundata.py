# -*- coding: utf-8 -*-
"""
SQLCipher v4 解密器 + 红蜻蜓 rundata 查询
密钥（来自反编译 k0/b.java）: 7fK9p2Qx4Rz6Yb8Wc3N5d1Ae0Vg7Hj2L
"""
import os, sys, struct, sqlite3, glob, traceback
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.hmac import HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes

PASSWORD = b"7fK9p2Qx4Rz6Yb8Wc3N5d1Ae0Vg7Hj2L"
PAGE_SIZE   = 4096
SALT_SIZE   = 16
IV_SIZE     = 16
KEY_LEN     = 32

# 尝试两套参数：v4 (PBKDF2-SHA512, 256000 iter, HMAC-SHA512, reserve=80)
#               v3 (PBKDF2-SHA1,   64000 iter, HMAC-SHA1,   reserve=32)
CONFIGS = [
    dict(name='v4', hash_alg=hashes.SHA512(), kdf_iter=256000, hmac_size=64, reserve=80),
    dict(name='v3', hash_alg=hashes.SHA1(),   kdf_iter=64000,  hmac_size=20, reserve=32),
    dict(name='v2', hash_alg=hashes.SHA1(),   kdf_iter=4000,   hmac_size=20, reserve=32),
    dict(name='v1', hash_alg=hashes.SHA1(),   kdf_iter=4000,   hmac_size=0,  reserve=16),
]

def derive_keys(password, salt, hash_alg, kdf_iter):
    kdf = PBKDF2HMAC(algorithm=hash_alg, length=KEY_LEN, salt=salt, iterations=kdf_iter)
    enc_key = kdf.derive(password)
    if not hash_alg:
        return enc_key, None
    hmac_salt = bytes(b ^ 0x3A for b in salt)
    kdf2 = PBKDF2HMAC(algorithm=hash_alg, length=KEY_LEN, salt=hmac_salt, iterations=2)
    hmac_key = kdf2.derive(enc_key)
    return enc_key, hmac_key


def try_decrypt(enc_data, cfg):
    reserve   = cfg['reserve']
    hmac_size = cfg['hmac_size']
    hash_alg  = cfg['hash_alg']

    if len(enc_data) < PAGE_SIZE:
        return None
    num_pages = len(enc_data) // PAGE_SIZE

    salt = enc_data[:SALT_SIZE]
    enc_key, hmac_key = derive_keys(PASSWORD, salt, hash_alg, cfg['kdf_iter'])

    cipher_end = PAGE_SIZE - reserve
    iv_start   = cipher_end
    iv_end     = iv_start + IV_SIZE
    hmac_start = iv_end

    out = bytearray()
    for page_num in range(1, num_pages + 1):
        offset = (page_num - 1) * PAGE_SIZE
        page = enc_data[offset:offset + PAGE_SIZE]
        iv = page[iv_start:iv_end]

        if page_num == 1:
            cipher_data = page[SALT_SIZE:cipher_end]
        else:
            cipher_data = page[:cipher_end]

        # Verify HMAC (if applicable)
        if hmac_size > 0:
            stored_hmac = page[hmac_start:hmac_start + hmac_size]
            h = HMAC(hmac_key, hash_alg)
            if page_num == 1:
                h.update(page[SALT_SIZE:cipher_end])
            else:
                h.update(page[:cipher_end])
            h.update(iv)
            h.update(struct.pack('<I', page_num))
            try:
                h.verify(stored_hmac)
            except Exception:
                return None  # HMAC mismatch → this config doesn't fit

        # Decrypt
        try:
            ciph = Cipher(algorithms.AES(enc_key), modes.CBC(iv))
            dec  = ciph.decryptor()
            plaintext = dec.update(cipher_data) + dec.finalize()
        except Exception:
            return None

        if page_num == 1:
            # 验证解密结果：bytes 18,19 应是 page-format version (1或2)
            if not (plaintext[2] in (1,2) and plaintext[3] in (1,2)):
                # 不像合法 SQLite header，参数错了
                return None
            out.extend(b"SQLite format 3\x00")
            out.extend(plaintext)
        else:
            out.extend(plaintext)
        out.extend(b'\x00' * reserve)

    return bytes(out), cfg['name']


def decrypt_file(enc_path, dec_path):
    with open(enc_path, 'rb') as f:
        enc = f.read()
    for cfg in CONFIGS:
        result = try_decrypt(enc, cfg)
        if result is not None:
            data, ver = result
            with open(dec_path, 'wb') as f:
                f.write(data)
            return ver
    return None


def query_rundata(dec_path):
    conn = sqlite3.connect(dec_path)
    conn.text_factory = lambda b: b.decode('utf-8', errors='replace')
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [r[0] for r in cur.fetchall()]

    rundata_info = {'total_rows': 0, 'total_distance': 0, 'rows': [], 'tables': tables}
    if 'rundata' in tables:
        cur.execute("SELECT COUNT(*), COALESCE(SUM(distance),0) FROM rundata")
        cnt, total = cur.fetchone()
        rundata_info['total_rows']     = cnt
        rundata_info['total_distance'] = total or 0

        cur.execute("""SELECT begintime, endtime, distance, time, status, eventno, studentno
                       FROM rundata ORDER BY rowid DESC LIMIT 10""")
        rundata_info['rows'] = cur.fetchall()

    # 也读一下学生信息，方便核对
    user_info = {}
    if 'users' in tables:
        try:
            cur.execute("SELECT * FROM users LIMIT 1")
            cols = [d[0] for d in cur.description]
            row = cur.fetchone()
            if row:
                user_info = dict(zip(cols, row))
        except Exception as e:
            user_info = {'_err': str(e)}

    school_info = {}
    if 'school' in tables:
        try:
            cur.execute("SELECT schoolno, schoolname, studentno FROM school WHERE status=1")
            row = cur.fetchone()
            if row:
                school_info = {'schoolno': row[0], 'schoolname': row[1], 'studentno': row[2]}
        except Exception:
            pass

    conn.close()
    return rundata_info, user_info, school_info


def main():
    enc_dir = r'C:\Users\Administrator\CascadeProjects\hongqingting-rundata\encrypted\hqt_dbs'
    dec_dir = r'C:\Users\Administrator\CascadeProjects\hongqingting-rundata\decrypted'
    os.makedirs(dec_dir, exist_ok=True)

    summary = []
    for enc_path in sorted(glob.glob(os.path.join(enc_dir, '*.db'))):
        name = os.path.basename(enc_path).replace('.db', '')
        dec_path = os.path.join(dec_dir, name + '.db')

        print(f"\n{'='*70}")
        print(f"📦 {name}  ({os.path.getsize(enc_path):,} 字节)")
        print(f"{'='*70}")

        ver = decrypt_file(enc_path, dec_path)
        if ver is None:
            print(f"  ❌ 4 种参数都解密失败")
            summary.append((name, '?', '?', '?', '解密失败'))
            continue
        print(f"  ✅ 解密成功 (SQLCipher {ver})")

        try:
            rd, ui, si = query_rundata(dec_path)
            print(f"  表: {rd['tables']}")
            if si:
                print(f"  学校: {si.get('schoolname','?')} (学号 {si.get('studentno','?')})")
            print(f"  rundata 记录数: {rd['total_rows']}")
            print(f"  rundata 总距离: {rd['total_distance']} 米 ({rd['total_distance']/1000:.2f} km)")

            if rd['rows']:
                print(f"  最近 10 条:")
                print(f"    {'begintime':<22} {'endtime':<22} {'distance(m)':<12} {'time(s)':<10} {'status':<6} {'eventno':<10}")
                for r in rd['rows']:
                    bt = str(r[0])[:22] if r[0] else '-'
                    et = str(r[1])[:22] if r[1] else '-'
                    print(f"    {bt:<22} {et:<22} {str(r[2] or 0):<12} {str(r[3] or 0):<10} {str(r[4] or '-'):<6} {str(r[5] or '-'):<10}")

            summary.append((name, ver, rd['total_rows'], rd['total_distance'],
                            si.get('studentno','-') if si else '-'))
        except Exception as e:
            print(f"  ❌ 查询出错: {e}")
            traceback.print_exc()
            summary.append((name, ver, '?', '?', '查询错误'))

    # 总结表
    print(f"\n\n{'='*80}")
    print(f"📊 11 个红蜻蜓克隆 — 跑步距离汇总")
    print(f"{'='*80}")
    print(f"{'包名':<30} {'cipher':<8} {'记录':>6} {'总距离(m)':>12} {'总(km)':>9} {'学号':<15}")
    print('-' * 80)
    for name, ver, c, d, sno in summary:
        if isinstance(d, (int, float)):
            print(f"{name:<30} {ver:<8} {c:>6} {d:>12.0f} {d/1000:>9.2f} {str(sno):<15}")
        else:
            print(f"{name:<30} {ver:<8} {str(c):>6} {str(d):>12} {'-':>9} {str(sno):<15}")


if __name__ == '__main__':
    main()
